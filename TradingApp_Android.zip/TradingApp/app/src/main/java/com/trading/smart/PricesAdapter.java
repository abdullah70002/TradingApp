package com.trading.smart;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class PricesAdapter extends RecyclerView.Adapter<PricesAdapter.ViewHolder> {

    public interface OnSymbolClick { void onClick(String symbol); }

    private List<String> symbols;
    private Map<String, Double> prices = new HashMap<>();
    private OnSymbolClick listener;

    public PricesAdapter(List<String> symbols, OnSymbolClick listener) {
        this.symbols = new ArrayList<>(symbols);
        this.listener = listener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_price, parent, false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        String symbol = symbols.get(position);
        holder.tvSymbol.setText(symbol.replace("USDT", "/USDT"));
        Double price = prices.get(symbol);
        if (price != null) {
            holder.tvPrice.setText("$" + TradeManager.formatPrice(price));
            holder.tvPrice.setTextColor(holder.itemView.getContext().getColor(R.color.green));
        } else {
            holder.tvPrice.setText("...");
            holder.tvPrice.setTextColor(holder.itemView.getContext().getColor(R.color.text_hint));
        }
        holder.itemView.setOnClickListener(v -> listener.onClick(symbol));
    }

    @Override
    public int getItemCount() { return symbols.size(); }

    public void updatePrice(String symbol, Double price) {
        prices.put(symbol, price);
        int idx = symbols.indexOf(symbol);
        if (idx >= 0) notifyItemChanged(idx);
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvSymbol, tvPrice;
        ViewHolder(View v) {
            super(v);
            tvSymbol = v.findViewById(R.id.tvSymbol);
            tvPrice = v.findViewById(R.id.tvPrice);
        }
    }
}
