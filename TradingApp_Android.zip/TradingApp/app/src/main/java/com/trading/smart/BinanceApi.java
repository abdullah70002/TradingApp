package com.trading.smart;

import retrofit2.Call;
import retrofit2.http.*;
import java.util.List;

public interface BinanceApi {

    @GET("api/v3/ticker/price")
    Call<PriceResponse> getPrice(@Query("symbol") String symbol);

    @GET("api/v3/exchangeInfo")
    Call<ExchangeInfoResponse> getExchangeInfo(@Query("symbol") String symbol);

    @GET("api/v3/account")
    Call<AccountResponse> getAccount(
            @Query("timestamp") long timestamp,
            @Query("signature") String signature,
            @Header("X-MBX-APIKEY") String apiKey
    );

    @POST("api/v3/order")
    Call<OrderResponse> createOrder(
            @Header("X-MBX-APIKEY") String apiKey,
            @Query("symbol") String symbol,
            @Query("side") String side,
            @Query("type") String type,
            @Query("quantity") String quantity,
            @Query("timestamp") long timestamp,
            @Query("signature") String signature
    );

    // OCO API الجديد (2024) - يستخدم aboveType و belowType
    @FormUrlEncoded
    @POST("api/v3/orderList/oco")
    Call<OcoResponse> createOcoOrder(
            @Header("X-MBX-APIKEY") String apiKey,
            @Field("symbol") String symbol,
            @Field("side") String side,
            @Field("quantity") String quantity,
            // الأمر الفوقي (Take Profit) - LIMIT_MAKER
            @Field("aboveType") String aboveType,
            @Field("abovePrice") String abovePrice,
            // الأمر السفلي (Stop Loss) - STOP_LOSS_LIMIT
            @Field("belowType") String belowType,
            @Field("belowStopPrice") String belowStopPrice,
            @Field("belowPrice") String belowPrice,
            @Field("belowTimeInForce") String belowTimeInForce,
            @Field("timestamp") long timestamp,
            @Field("signature") String signature
    );

    // Models
    class PriceResponse { public String symbol, price; }

    class ExchangeInfoResponse {
        public List<Symbol> symbols;
        class Symbol { public String symbol; public List<Filter> filters; }
        class Filter { public String filterType, stepSize, minQty, tickSize; }
    }

    class AccountResponse {
        public List<Balance> balances;
        class Balance { public String asset, free, locked; }
    }

    class OrderResponse {
        public long orderId;
        public String symbol, status, executedQty;
        public List<Fill> fills;
        class Fill { public String price, qty; }
    }

    class OcoResponse {
        public long orderListId;
        public String symbol, listOrderStatus;
    }
}
