package com.trading.smart;

import android.content.Context;
import android.content.SharedPreferences;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class TradeManager {

    private static final String PREFS_NAME = "TradingAppPrefs";
    private static final String TRADES_KEY = "trades";
    private static final String API_KEY_PREF = "api_key";
    private static final String API_SECRET = "api_secret";
    private static final String RISK_AMOUNT = "risk_amount";
    private static final String REWARD_AMOUNT = "reward_amount";
    private static final String TRADING_PAIRS = "trading_pairs";

    private static TradeManager instance;
    private SharedPreferences prefs;
    private Gson gson = new Gson();

    public static TradeManager getInstance(Context context) {
        if (instance == null) instance = new TradeManager(context.getApplicationContext());
        return instance;
    }

    private TradeManager(Context ctx) {
        prefs = ctx.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
    }

    public static class Trade {
        public String id, date, symbol, status, orderId, riskRewardRatio;
        public double entryPrice, positionSize, stopLoss, takeProfit, riskAmount, potentialProfit;
        public boolean ocoSet;
        public Trade() {
            this.id = String.valueOf(System.currentTimeMillis());
            this.status = "pending";
            this.date = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(new Date());
        }
    }

    public String getApiKey()      { return prefs.getString(API_KEY_PREF, ""); }
    public String getApiSecret()   { return prefs.getString(API_SECRET, ""); }
    public double getRiskAmount()  { return Double.parseDouble(prefs.getString(RISK_AMOUNT, "0.5")); }
    public double getRewardAmount(){ return Double.parseDouble(prefs.getString(REWARD_AMOUNT, "1.15")); }

    public List<String> getTradingPairs() {
        String json = prefs.getString(TRADING_PAIRS, null);
        if (json == null) {
            List<String> d = new ArrayList<>();
            d.add("BTCUSDT"); d.add("ETHUSDT"); d.add("BNBUSDT");
            d.add("ADAUSDT"); d.add("PEPEUSDT"); d.add("DOTUSDT");
            return d;
        }
        return gson.fromJson(json, new TypeToken<List<String>>(){}.getType());
    }

    public void saveSettings(String apiKey, String apiSecret, double risk, double reward, List<String> pairs) {
        prefs.edit()
                .putString(API_KEY_PREF, apiKey)
                .putString(API_SECRET, apiSecret)
                .putString(RISK_AMOUNT, String.valueOf(risk))
                .putString(REWARD_AMOUNT, String.valueOf(reward))
                .putString(TRADING_PAIRS, gson.toJson(pairs))
                .apply();
    }

    public List<Trade> getAllTrades() {
        String json = prefs.getString(TRADES_KEY, null);
        if (json == null) return new ArrayList<>();
        return gson.fromJson(json, new TypeToken<List<Trade>>(){}.getType());
    }

    public void addTrade(Trade t) {
        List<Trade> trades = getAllTrades();
        trades.add(0, t);
        prefs.edit().putString(TRADES_KEY, gson.toJson(trades)).apply();
    }

    public void updateTradeStatus(String id, String status) {
        List<Trade> trades = getAllTrades();
        for (Trade t : trades) if (t.id.equals(id)) { t.status = status; break; }
        prefs.edit().putString(TRADES_KEY, gson.toJson(trades)).apply();
    }

    public List<Trade> getPendingTrades() {
        List<Trade> r = new ArrayList<>();
        for (Trade t : getAllTrades()) if ("pending".equals(t.status)) r.add(t);
        return r;
    }

    public void clearAllTrades() {
        prefs.edit().remove(TRADES_KEY).apply();
    }

    public static class Stats {
        public int total, wins, losses;
        public double winRate;
    }

    public Stats getStats(List<Trade> trades) {
        Stats s = new Stats();
        for (Trade t : trades) {
            if ("winning".equals(t.status)) { s.wins++; s.total++; }
            else if ("losing".equals(t.status)) { s.losses++; s.total++; }
        }
        s.winRate = s.total > 0 ? (s.wins * 100.0 / s.total) : 0;
        return s;
    }

    public Stats getAllTimeStats() { return getStats(getAllTrades()); }

    public static double calcPositionSize(double entry, double sl, double risk) {
        double riskPct = (entry - sl) / entry;
        if (riskPct <= 0) return 0;
        return Math.round(risk / riskPct * 100.0) / 100.0;
    }

    public static double calcTakeProfit(double entry, double reward, double size) {
        if (size <= 0) return 0;
        return entry + (reward / (size / entry));
    }

    /**
     * تنسيق السعر بدقة كاملة - مثل TradingView تماماً
     */
    public static String formatPrice(double price) {
        if (price == 0) return "0";
        if (price >= 10000)  return String.format(Locale.US, "%.2f", price);
        if (price >= 1000)   return String.format(Locale.US, "%.2f", price);
        if (price >= 100)    return String.format(Locale.US, "%.3f", price);
        if (price >= 1)      return String.format(Locale.US, "%.4f", price);
        if (price >= 0.1)    return String.format(Locale.US, "%.5f", price);
        if (price >= 0.01)   return String.format(Locale.US, "%.6f", price);
        if (price >= 0.001)  return String.format(Locale.US, "%.7f", price);
        return String.format(Locale.US, "%.8f", price);
    }
}
