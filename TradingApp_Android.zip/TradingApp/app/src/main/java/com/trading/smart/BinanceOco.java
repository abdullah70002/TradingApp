package com.trading.smart;

import android.os.Handler;
import android.os.Looper;
import org.apache.commons.codec.binary.Hex;
import okhttp3.*;
import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.io.IOException;

/**
 * OCO بـ OkHttp مباشرة - نفس طريقة Python
 * يحل مشكلة signature -1022
 */
public class BinanceOco {

    private static final String BASE_URL = "https://api.binance.com";
    private OkHttpClient client = new OkHttpClient();
    private Handler mainHandler = new Handler(Looper.getMainLooper());

    public interface OcoCallback {
        void onSuccess(String orderListId);
        void onError(String error);
    }

    /**
     * ينفذ OCO - نفس منطق Python:
     *   tp  = abovePrice  (LIMIT_MAKER)
     *   sl  = belowStopPrice (STOP_LOSS_LIMIT trigger)
     *   slLimit = belowPrice (السعر الفعلي للبيع عند الـ SL)
     */
    public void placeOco(String apiKey, String apiSecret,
                          String symbol, String qty,
                          String tp, String sl, String slLimit,
                          OcoCallback callback) {

        long timestamp = System.currentTimeMillis();

        // بناء body params - مرتبة أبجدياً للـ signature
        String paramsToSign =
                "abovePrice=" + tp +
                "&aboveType=LIMIT_MAKER" +
                "&belowPrice=" + slLimit +
                "&belowStopPrice=" + sl +
                "&belowTimeInForce=GTC" +
                "&belowType=STOP_LOSS_LIMIT" +
                "&quantity=" + qty +
                "&side=SELL" +
                "&symbol=" + symbol +
                "&timestamp=" + timestamp;

        String signature = hmac256(paramsToSign, apiSecret);

        // بناء الـ body الكامل مع الـ signature
        String fullBody = paramsToSign + "&signature=" + signature;

        RequestBody body = RequestBody.create(
                fullBody,
                MediaType.parse("application/x-www-form-urlencoded")
        );

        Request request = new Request.Builder()
                .url(BASE_URL + "/api/v3/orderList/oco")
                .header("X-MBX-APIKEY", apiKey)
                .header("Content-Type", "application/x-www-form-urlencoded")
                .post(body)
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onResponse(Call call, Response response) throws IOException {
                String respBody = response.body() != null ? response.body().string() : "";
                if (response.isSuccessful()) {
                    // جلب orderListId من الـ response
                    String id = extractField(respBody, "orderListId");
                    mainHandler.post(() -> callback.onSuccess(id));
                } else {
                    mainHandler.post(() -> callback.onError(respBody));
                }
            }

            @Override
            public void onFailure(Call call, IOException e) {
                mainHandler.post(() -> callback.onError("فشل الاتصال: " + e.getMessage()));
            }
        });
    }

    // HMAC-SHA256 - نفس Python
    private String hmac256(String data, String secret) {
        try {
            Mac mac = Mac.getInstance("HmacSHA256");
            mac.init(new SecretKeySpec(secret.getBytes("UTF-8"), "HmacSHA256"));
            return new String(Hex.encodeHex(mac.doFinal(data.getBytes("UTF-8"))));
        } catch (Exception e) {
            return "";
        }
    }

    // استخراج قيمة من JSON بسيط
    private String extractField(String json, String field) {
        try {
            int idx = json.indexOf("\"" + field + "\":");
            if (idx < 0) return "0";
            int start = idx + field.length() + 3;
            int end = json.indexOf(",", start);
            if (end < 0) end = json.indexOf("}", start);
            return json.substring(start, end).replace("\"", "").trim();
        } catch (Exception e) {
            return "0";
        }
    }
}
