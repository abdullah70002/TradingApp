package com.trading.smart;

import android.os.Handler;
import android.os.Looper;
import com.google.gson.Gson;
import com.google.gson.annotations.SerializedName;
import okhttp3.*;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * أسعار مباشرة عبر WebSocket من Binance - تحديث لحظي حقيقي
 */
public class BinanceWebSocket {

    public interface PriceListener {
        void onPrice(String symbol, double price);
    }

    private static BinanceWebSocket instance;
    private OkHttpClient client;
    private WebSocket webSocket;
    private Handler mainHandler = new Handler(Looper.getMainLooper());
    private Map<String, Double> prices = new HashMap<>();
    private Map<String, PriceListener> listeners = new HashMap<>();
    private Gson gson = new Gson();
    private boolean connected = false;

    public static BinanceWebSocket getInstance() {
        if (instance == null) instance = new BinanceWebSocket();
        return instance;
    }

    private BinanceWebSocket() {
        client = new OkHttpClient();
    }

    // تسجيل مستمع للسعر
    public void subscribe(String symbol, PriceListener listener) {
        listeners.put(symbol.toLowerCase(), listener);
    }

    public void unsubscribe(String symbol) {
        listeners.remove(symbol.toLowerCase());
    }

    // بدء اتصال WebSocket لقائمة عملات
    public void connect(List<String> symbols) {
        disconnect();

        // بناء stream URL: btcusdt@ticker/ethusdt@ticker/...
        StringBuilder sb = new StringBuilder("wss://stream.binance.com:9443/stream?streams=");
        for (int i = 0; i < symbols.size(); i++) {
            sb.append(symbols.get(i).toLowerCase()).append("@ticker");
            if (i < symbols.size() - 1) sb.append("/");
        }

        Request request = new Request.Builder().url(sb.toString()).build();
        webSocket = client.newWebSocket(request, new WebSocketListener() {
            @Override
            public void onOpen(WebSocket ws, Response response) {
                connected = true;
            }

            @Override
            public void onMessage(WebSocket ws, String text) {
                try {
                    StreamMessage msg = gson.fromJson(text, StreamMessage.class);
                    if (msg != null && msg.data != null) {
                        String sym = msg.data.symbol;
                        double price = Double.parseDouble(msg.data.price);
                        prices.put(sym, price);
                        String key = sym.toLowerCase();
                        if (listeners.containsKey(key)) {
                            mainHandler.post(() -> listeners.get(key).onPrice(sym, price));
                        }
                        // إشعار كل المستمعين بأي سعر
                        mainHandler.post(() -> {
                            for (Map.Entry<String, PriceListener> entry : listeners.entrySet()) {
                                if (entry.getKey().equals(key)) {
                                    entry.getValue().onPrice(sym, price);
                                }
                            }
                        });
                    }
                } catch (Exception ignored) {}
            }

            @Override
            public void onFailure(WebSocket ws, Throwable t, Response response) {
                connected = false;
                // إعادة الاتصال بعد 3 ثوان
                mainHandler.postDelayed(() -> connect(symbols), 3000);
            }

            @Override
            public void onClosed(WebSocket ws, int code, String reason) {
                connected = false;
            }
        });
    }

    public void disconnect() {
        if (webSocket != null) {
            webSocket.close(1000, "bye");
            webSocket = null;
        }
        connected = false;
    }

    public double getPrice(String symbol) {
        Double p = prices.get(symbol.toUpperCase());
        return p != null ? p : 0;
    }

    public boolean isConnected() { return connected; }

    // نموذج البيانات
    static class StreamMessage {
        @SerializedName("data")
        public TickerData data;
    }

    static class TickerData {
        @SerializedName("s") public String symbol;
        @SerializedName("c") public String price; // "c" = آخر سعر
        @SerializedName("P") public String changePercent; // نسبة التغير
    }
}
