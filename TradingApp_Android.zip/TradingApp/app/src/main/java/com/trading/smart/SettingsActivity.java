package com.trading.smart;

import android.os.Bundle;
import android.view.MenuItem;
import android.widget.*;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.textfield.TextInputEditText;
import java.util.Arrays;
import java.util.List;

public class SettingsActivity extends AppCompatActivity {

    private TradeManager tradeManager;
    private BinanceService binanceService;
    private TextInputEditText etApiKey, etApiSecret, etRisk, etReward, etPairs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        tradeManager = TradeManager.getInstance(this);
        binanceService = BinanceService.getInstance();

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("الإعدادات");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        etApiKey    = findViewById(R.id.etApiKey);
        etApiSecret = findViewById(R.id.etApiSecret);
        etRisk      = findViewById(R.id.etRisk);
        etReward    = findViewById(R.id.etReward);
        etPairs     = findViewById(R.id.etPairs);

        loadCurrentSettings();

        findViewById(R.id.btnSave).setOnClickListener(v -> saveSettings());
        findViewById(R.id.btnTestConnection).setOnClickListener(v -> testConnection());
        findViewById(R.id.btnApiHelp).setOnClickListener(v -> showApiHelp());
    }

    private void loadCurrentSettings() {
        etApiKey.setText(tradeManager.getApiKey());
        etApiSecret.setText(tradeManager.getApiSecret());
        etRisk.setText(String.valueOf(tradeManager.getRiskAmount()));
        etReward.setText(String.valueOf(tradeManager.getRewardAmount()));
        etPairs.setText(String.join(",", tradeManager.getTradingPairs()));
    }

    private void saveSettings() {
        String apiKey    = etApiKey.getText().toString().trim();
        String apiSecret = etApiSecret.getText().toString().trim();
        String riskStr   = etRisk.getText().toString().trim();
        String rewardStr = etReward.getText().toString().trim();
        String pairsStr  = etPairs.getText().toString().trim();

        if (riskStr.isEmpty() || rewardStr.isEmpty()) {
            Snackbar.make(etRisk, "أدخل قيم المخاطرة والمكافأة", Snackbar.LENGTH_SHORT).show();
            return;
        }

        double risk, reward;
        try {
            risk   = Double.parseDouble(riskStr);
            reward = Double.parseDouble(rewardStr);
        } catch (Exception e) {
            Snackbar.make(etRisk, "قيم غير صحيحة", Snackbar.LENGTH_SHORT).show();
            return;
        }

        List<String> pairs = Arrays.asList(pairsStr.toUpperCase().split(","));
        tradeManager.saveSettings(apiKey, apiSecret, risk, reward, pairs);
        Snackbar.make(etRisk, "✓ تم حفظ الإعدادات", Snackbar.LENGTH_SHORT).show();
    }

    private void testConnection() {
        String apiKey    = etApiKey.getText().toString().trim();
        String apiSecret = etApiSecret.getText().toString().trim();

        if (apiKey.isEmpty() || apiSecret.isEmpty()) {
            Snackbar.make(etApiKey, "أدخل مفاتيح API أولاً", Snackbar.LENGTH_SHORT).show();
            return;
        }

        Snackbar.make(etApiKey, "جاري الاتصال...", Snackbar.LENGTH_SHORT).show();

        binanceService.getBalance(apiKey, apiSecret, new BinanceService.Callback<Double>() {
            @Override
            public void onSuccess(Double balance) {
                Snackbar.make(etApiKey,
                        "✓ الاتصال ناجح! الرصيد: $" + TradeManager.formatPrice(balance),
                        Snackbar.LENGTH_LONG).show();
            }
            @Override
            public void onError(String error) {
                showApiErrorHelp(error);
            }
        });
    }

    private void showApiErrorHelp(String error) {
        String msg;
        if (error.contains("-2015") || error.contains("Invalid API")) {
            msg = "❌ خطأ في مفاتيح API\n\n" +
                  "السبب الأكثر شيوعاً:\n\n" +
                  "1️⃣ في Binance → API Management\n" +
                  "   افتح المفتاح الخاص بك\n\n" +
                  "2️⃣ في قسم 'IP access restrictions'\n" +
                  "   اختر: Unrestricted\n\n" +
                  "3️⃣ تأكد من تفعيل:\n" +
                  "   ✅ Enable Reading\n" +
                  "   ✅ Enable Spot & Margin Trading\n\n" +
                  "4️⃣ إذا لم تنفع، احذف المفتاح وأنشئ جديداً";
        } else {
            msg = "❌ فشل الاتصال\n\n" + error;
        }

        new AlertDialog.Builder(this)
            .setTitle("مشكلة في الاتصال")
            .setMessage(msg)
            .setPositiveButton("فهمت", null)
            .show();
    }

    private void showApiHelp() {
        new AlertDialog.Builder(this)
            .setTitle("🔑 كيف تحصل على مفاتيح API؟")
            .setMessage(
                "1️⃣ افتح تطبيق Binance\n\n" +
                "2️⃣ الملف الشخصي ← API Management\n\n" +
                "3️⃣ اضغط 'Create API'\n\n" +
                "4️⃣ اختر 'System Generated'\n\n" +
                "5️⃣ فعّل هذه الصلاحيات:\n" +
                "   ✅ Enable Reading\n" +
                "   ✅ Enable Spot & Margin Trading\n" +
                "   ❌ لا تفعل Withdrawals\n\n" +
                "6️⃣ في 'IP access restrictions'\n" +
                "   اختر: Unrestricted\n\n" +
                "7️⃣ انسخ API Key و Secret Key\n" +
                "   والصقهم هنا"
            )
            .setPositiveButton("موافق", null)
            .show();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) { finish(); return true; }
        return super.onOptionsItemSelected(item);
    }
}
