package com.trading.smart;

import android.graphics.Color;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import com.google.android.material.snackbar.Snackbar;
import java.util.List;

public class ReviewActivity extends AppCompatActivity {

    private TradeManager tradeManager;
    private LinearLayout llTrades;
    private TextView tvNoPending;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_review);

        tradeManager = TradeManager.getInstance(this);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("مراجعة الصفقات");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        llTrades = findViewById(R.id.llTrades);
        tvNoPending = findViewById(R.id.tvNoPending);

        loadPendingTrades();
    }

    private void loadPendingTrades() {
        llTrades.removeAllViews();
        List<TradeManager.Trade> pending = tradeManager.getPendingTrades();

        if (pending.isEmpty()) {
            tvNoPending.setVisibility(View.VISIBLE);
            return;
        }
        tvNoPending.setVisibility(View.GONE);

        for (TradeManager.Trade trade : pending) {
            View card = buildTradeCard(trade);
            llTrades.addView(card);
        }
    }


    private View buildTradeCard(TradeManager.Trade trade) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setBackgroundResource(R.drawable.card_bg);
        int pad = (int) (16 * getResources().getDisplayMetrics().density);
        card.setPadding(pad, pad, pad, pad);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, 0, 0, (int) (12 * getResources().getDisplayMetrics().density));
        card.setLayoutParams(lp);

        // Symbol and date
        TextView tvHeader = new TextView(this);
        tvHeader.setText(trade.symbol + "  |  " + trade.date.substring(0, 10));
        tvHeader.setTextColor(getColor(R.color.gold));
        tvHeader.setTextSize(15);
        tvHeader.setTypeface(null, android.graphics.Typeface.BOLD);
        tvHeader.setGravity(android.view.Gravity.END);
        card.addView(tvHeader);

        // Details
        TextView tvDetails = new TextView(this);
        tvDetails.setText(
                "دخول: " + TradeManager.formatPrice(trade.entryPrice) +
                "  |  هدف: " + TradeManager.formatPrice(trade.takeProfit) +
                "  |  وقف: " + TradeManager.formatPrice(trade.stopLoss)
        );
        tvDetails.setTextColor(getColor(R.color.text_secondary));
        tvDetails.setTextSize(13);
        tvDetails.setGravity(android.view.Gravity.END);
        int mt = (int) (6 * getResources().getDisplayMetrics().density);
        LinearLayout.LayoutParams dLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        dLp.setMargins(0, mt, 0, mt);
        tvDetails.setLayoutParams(dLp);
        card.addView(tvDetails);

        // RR ratio
        TextView tvRR = new TextView(this);
        tvRR.setText("نسبة: " + trade.riskRewardRatio);
        tvRR.setTextColor(getColor(R.color.yellow));
        tvRR.setTextSize(13);
        tvRR.setGravity(android.view.Gravity.END);
        card.addView(tvRR);

        // Buttons
        LinearLayout btnRow = new LinearLayout(this);
        btnRow.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams brLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        brLp.setMargins(0, mt * 2, 0, 0);
        btnRow.setLayoutParams(brLp);

        Button btnWin = new Button(this);
        btnWin.setText("✓ رابحة");
        btnWin.setBackgroundColor(getColor(R.color.green_dark));
        btnWin.setTextColor(Color.WHITE);
        LinearLayout.LayoutParams bLp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        bLp.setMargins(0, 0, (int)(6*getResources().getDisplayMetrics().density), 0);
        btnWin.setLayoutParams(bLp);
        btnWin.setOnClickListener(v -> markTrade(trade, "winning"));

        Button btnLoss = new Button(this);
        btnLoss.setText("✗ خاسرة");
        btnLoss.setBackgroundColor(getColor(R.color.red_dark));
        btnLoss.setTextColor(Color.WHITE);
        LinearLayout.LayoutParams bLp2 = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        btnLoss.setLayoutParams(bLp2);
        btnLoss.setOnClickListener(v -> markTrade(trade, "losing"));

        btnRow.addView(btnLoss);
        btnRow.addView(btnWin);
        card.addView(btnRow);

        return card;
    }

    private void markTrade(TradeManager.Trade trade, String status) {
        tradeManager.updateTradeStatus(trade.id, status);
        String msg = "winning".equals(status) ? "✓ صفقة رابحة" : "✗ صفقة خاسرة";
        Snackbar.make(llTrades, msg, Snackbar.LENGTH_SHORT).show();
        loadPendingTrades();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) { finish(); return true; }
        return super.onOptionsItemSelected(item);
    }
}
