package com.trading.smart;

import android.content.ContentValues;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.view.MenuItem;
import android.widget.TextView;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import com.google.android.material.snackbar.Snackbar;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class StatisticsActivity extends AppCompatActivity {

    private TradeManager tradeManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_statistics);

        tradeManager = TradeManager.getInstance(this);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("الإحصائيات");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        loadStats();
        findViewById(R.id.btnExport).setOnClickListener(v -> exportToTxt());
        findViewById(R.id.btnClear).setOnClickListener(v -> showClearDialog());
    }

    private void loadStats() {
        List<TradeManager.Trade> all = tradeManager.getAllTrades();
        String curMonth = new SimpleDateFormat("yyyy-MM", Locale.getDefault()).format(new Date());
        String curYear  = new SimpleDateFormat("yyyy",    Locale.getDefault()).format(new Date());
        long sixAgo = System.currentTimeMillis() - 180L * 86400000L;

        List<TradeManager.Trade> monthly = new ArrayList<>(), semi = new ArrayList<>(), yearly = new ArrayList<>();
        for (TradeManager.Trade t : all) {
            try {
                Date d = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).parse(t.date);
                if (d == null) continue;
                if (new SimpleDateFormat("yyyy-MM", Locale.getDefault()).format(d).equals(curMonth)) monthly.add(t);
                if (d.getTime() >= sixAgo) semi.add(t);
                if (new SimpleDateFormat("yyyy", Locale.getDefault()).format(d).equals(curYear)) yearly.add(t);
            } catch (Exception ignored) {}
        }

        set(monthly, R.id.tvMonthlyWin, R.id.tvMonthlyLoss, R.id.tvMonthlyRate, R.id.tvMonthlyTotal);
        set(semi,    R.id.tvSemiWin,    R.id.tvSemiLoss,    R.id.tvSemiRate,    R.id.tvSemiTotal);
        set(yearly,  R.id.tvYearlyWin,  R.id.tvYearlyLoss,  R.id.tvYearlyRate,  R.id.tvYearlyTotal);
        set(all,     R.id.tvAllWin,     R.id.tvAllLoss,     R.id.tvAllRate,     R.id.tvAllTotal);
    }

    private void set(List<TradeManager.Trade> trades, int w, int l, int r, int t) {
        TradeManager.Stats s = tradeManager.getStats(trades);
        ((TextView) findViewById(w)).setText(String.valueOf(s.wins));
        ((TextView) findViewById(l)).setText(String.valueOf(s.losses));
        ((TextView) findViewById(r)).setText(String.format(Locale.US, "%.1f%%", s.winRate));
        ((TextView) findViewById(t)).setText("الكلي: " + s.total);
    }

    private void exportToTxt() {
        List<TradeManager.Trade> all = tradeManager.getAllTrades();
        if (all.isEmpty()) {
            Snackbar.make(findViewById(android.R.id.content), "لا توجد صفقات", Snackbar.LENGTH_SHORT).show();
            return;
        }

        StringBuilder sb = new StringBuilder();
        String now = new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(new Date());
        TradeManager.Stats stats = tradeManager.getAllTimeStats();

        sb.append("═══════════════════════════════\n")
          .append("   أداة التداول الذكية - تقرير\n")
          .append("   ").append(now).append("\n")
          .append("═══════════════════════════════\n\n")
          .append("الإجمالي الكلي:\n")
          .append("  رابحة:      ").append(stats.wins).append("\n")
          .append("  خاسرة:      ").append(stats.losses).append("\n")
          .append("  نسبة الفوز: ").append(String.format(Locale.US, "%.1f%%", stats.winRate)).append("\n\n")
          .append("───────────────────────────────\n")
          .append("تفاصيل الصفقات:\n")
          .append("───────────────────────────────\n\n");

        for (int i = 0; i < all.size(); i++) {
            TradeManager.Trade t = all.get(i);
            String st = "winning".equals(t.status) ? "رابحة ✓" : "losing".equals(t.status) ? "خاسرة ✗" : "قيد المراجعة";
            sb.append("#").append(i + 1).append(" | ").append(t.symbol).append(" | ").append(t.date).append("\n")
              .append("  دخول: ").append(TradeManager.formatPrice(t.entryPrice))
              .append("  SL: ").append(TradeManager.formatPrice(t.stopLoss))
              .append("  TP: ").append(TradeManager.formatPrice(t.takeProfit)).append("\n")
              .append("  حجم: $").append(TradeManager.formatPrice(t.positionSize))
              .append("  R: $").append(t.riskAmount).append("  RW: $").append(t.potentialProfit).append("\n")
              .append("  النتيجة: ").append(st).append(" | أمر: ").append(t.orderId).append("\n\n");
        }

        String fileName = "trading_" + new SimpleDateFormat("yyyyMMdd_HHmm", Locale.getDefault()).format(new Date()) + ".txt";
        String savedPath = "";

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                // Android 10+ - MediaStore
                ContentValues values = new ContentValues();
                values.put(MediaStore.Downloads.DISPLAY_NAME, fileName);
                values.put(MediaStore.Downloads.MIME_TYPE, "text/plain");
                values.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
                Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
                if (uri != null) {
                    try (OutputStream os = getContentResolver().openOutputStream(uri)) {
                        os.write(sb.toString().getBytes("UTF-8"));
                    }
                    savedPath = "التنزيلات/" + fileName;
                }
            } else {
                // Android < 10
                File dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
                File file = new File(dir, fileName);
                try (FileWriter fw = new FileWriter(file)) { fw.write(sb.toString()); }
                savedPath = file.getAbsolutePath();
            }

            String finalPath = savedPath;
            new AlertDialog.Builder(this)
                .setTitle("✅ تم التصدير!")
                .setMessage("تم حفظ التقرير في:\n📁 " + finalPath + "\n\nافتح تطبيق 'الملفات' → التنزيلات")
                .setPositiveButton("موافق", null)
                .show();

        } catch (Exception e) {
            Snackbar.make(findViewById(android.R.id.content), "خطأ: " + e.getMessage(), Snackbar.LENGTH_LONG).show();
        }
    }

    private void showClearDialog() {
        new AlertDialog.Builder(this)
            .setTitle("⚠ تحذير")
            .setMessage("هل تريد مسح جميع الصفقات والإحصائيات؟\nلا يمكن التراجع عن هذا!")
            .setPositiveButton("نعم، امسح كل شيء", (d, w) -> {
                tradeManager.clearAllTrades();
                loadStats();
                Snackbar.make(findViewById(android.R.id.content), "✓ تم المسح", Snackbar.LENGTH_SHORT).show();
            })
            .setNegativeButton("إلغاء", null)
            .show();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) { finish(); return true; }
        return super.onOptionsItemSelected(item);
    }
}
