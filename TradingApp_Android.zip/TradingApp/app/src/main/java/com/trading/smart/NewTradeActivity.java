package com.trading.smart;

import android.os.Bundle;
import android.os.Handler;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.MenuItem;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.textfield.TextInputEditText;
import java.util.Collections;
import java.util.Locale;

public class NewTradeActivity extends AppCompatActivity {

    private TradeManager tradeManager;
    private BinanceService binanceService;
    private BinanceWebSocket wsClient;
    private BinanceOco binanceOco;

    private TextView tvCurrentPrice;
    private TextInputEditText etSymbol, etStopLoss;
    private LinearLayout layoutResults;
    private TextView tvCalcSize, tvCalcTP, tvCalcSL, tvCalcRisk, tvCalcReward;
    private MaterialButton btnFetch, btnCalculate, btnExecute;

    private String selectedSymbol = "";
    private double currentPrice = 0;
    private double calculatedSize = 0;
    private double calculatedTP = 0;
    private BinanceService.SymbolInfo symbolInfo = new BinanceService.SymbolInfo();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_trade);

        tradeManager = TradeManager.getInstance(this);
        binanceService = BinanceService.getInstance();
        wsClient       = BinanceWebSocket.getInstance();
        binanceOco     = new BinanceOco();

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("صفقة جديدة");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        tvCurrentPrice = findViewById(R.id.tvCurrentPrice);
        etSymbol       = findViewById(R.id.etSymbol);
        etStopLoss     = findViewById(R.id.etStopLoss);
        layoutResults  = findViewById(R.id.layoutResults);
        tvCalcSize     = findViewById(R.id.tvCalcSize);
        tvCalcTP       = findViewById(R.id.tvCalcTP);
        tvCalcSL       = findViewById(R.id.tvCalcSL);
        tvCalcRisk     = findViewById(R.id.tvCalcRisk);
        tvCalcReward   = findViewById(R.id.tvCalcReward);
        btnFetch       = findViewById(R.id.btnFetch);
        btnCalculate   = findViewById(R.id.btnCalculate);
        btnExecute     = findViewById(R.id.btnExecute);

        btnFetch.setOnClickListener(v -> fetchSymbol());
        btnCalculate.setOnClickListener(v -> calculateTrade());
        btnExecute.setOnClickListener(v -> showConfirmDialog());
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (!selectedSymbol.isEmpty()) wsClient.unsubscribe(selectedSymbol);
    }

    private void fetchSymbol() {
        String input = etSymbol.getText().toString().trim().toUpperCase();
        if (input.isEmpty()) {
            Snackbar.make(btnFetch, "أدخل رمز العملة", Snackbar.LENGTH_SHORT).show();
            return;
        }
        // أضف USDT تلقائياً إذا المستخدم كتب الرمز فقط بدون زوج
        if (!input.endsWith("USDT") && !input.endsWith("BUSD") && !input.endsWith("USDC") 
                && !(input.length() > 4 && (input.endsWith("BTC") || input.endsWith("ETH") || input.endsWith("BNB")))) {
            input += "USDT";
            etSymbol.setText(input);
        }
        selectedSymbol = input;
        tvCurrentPrice.setText("⏳ جاري الجلب...");
        tvCurrentPrice.setTextColor(getColor(R.color.text_secondary));
        btnFetch.setEnabled(false);
        layoutResults.setVisibility(View.GONE);
        btnExecute.setVisibility(View.GONE);

        final String symbol = selectedSymbol;

        // جلب معلومات الدقة أولاً
        binanceService.getSymbolInfo(symbol, new BinanceService.Callback<BinanceService.SymbolInfo>() {
            @Override
            public void onSuccess(BinanceService.SymbolInfo info) {
                symbolInfo = info;
                // ثم WebSocket للسعر اللحظي
                wsClient.connect(Collections.singletonList(symbol));
                wsClient.subscribe(symbol, (sym, price) -> {
                    currentPrice = price;
                    tvCurrentPrice.setText("● " + TradeManager.formatPrice(price) + " $");
                    tvCurrentPrice.setTextColor(getColor(R.color.green));
                });
                // أول قيمة عبر REST للسرعة
                binanceService.getPrice(symbol, new BinanceService.Callback<Double>() {
                    @Override
                    public void onSuccess(Double price) {
                        currentPrice = price;
                        tvCurrentPrice.setText("● " + TradeManager.formatPrice(price) + " $");
                        tvCurrentPrice.setTextColor(getColor(R.color.green));
                        btnFetch.setEnabled(true);
                    }
                    @Override
                    public void onError(String error) {
                        tvCurrentPrice.setText("⚠ رمز غير صحيح: " + symbol);
                        tvCurrentPrice.setTextColor(getColor(R.color.red));
                        btnFetch.setEnabled(true);
                    }
                });
            }
            @Override
            public void onError(String e) { btnFetch.setEnabled(true); }
        });
    }

    private void calculateTrade() {
        String slText = etStopLoss.getText().toString().trim().replace(",", "");
        if (slText.isEmpty()) { Snackbar.make(btnCalculate, "أدخل وقف الخسارة", Snackbar.LENGTH_SHORT).show(); return; }
        double sl;
        try { sl = Double.parseDouble(slText); }
        catch (Exception e) { Snackbar.make(btnCalculate, "قيمة غير صحيحة", Snackbar.LENGTH_SHORT).show(); return; }

        if (currentPrice <= 0) { Snackbar.make(btnCalculate, "اجلب السعر أولاً", Snackbar.LENGTH_SHORT).show(); return; }
        if (sl >= currentPrice) { Snackbar.make(btnCalculate, "وقف الخسارة يجب أن يكون أقل من السعر الحالي", Snackbar.LENGTH_SHORT).show(); return; }

        double risk   = tradeManager.getRiskAmount();
        double reward = tradeManager.getRewardAmount();
        calculatedSize = TradeManager.calcPositionSize(currentPrice, sl, risk);
        calculatedTP   = TradeManager.calcTakeProfit(currentPrice, reward, calculatedSize);

        tvCalcSize.setText("$" + TradeManager.formatPrice(calculatedSize));
        tvCalcTP.setText(TradeManager.formatPrice(calculatedTP));
        tvCalcSL.setText(TradeManager.formatPrice(sl));
        tvCalcRisk.setText("$" + risk);
        tvCalcReward.setText("$" + reward);
        layoutResults.setVisibility(View.VISIBLE);
        btnExecute.setVisibility(View.VISIBLE);
    }

    private void showConfirmDialog() {
        double sl = Double.parseDouble(etStopLoss.getText().toString().trim().replace(",", ""));
        double qty = calculatedSize / currentPrice;
        String qtyStr = BinanceService.roundQty(qty, symbolInfo.stepSize);
        double rr = tradeManager.getRewardAmount() / tradeManager.getRiskAmount();

        new AlertDialog.Builder(this)
            .setTitle("⚡ تأكيد الصفقة")
            .setMessage(
                "الزوج:        " + selectedSymbol + "\n" +
                "سعر الدخول:   " + TradeManager.formatPrice(currentPrice) + "\n" +
                "الكمية:       " + qtyStr + "\n" +
                "حجم المركز:   $" + TradeManager.formatPrice(calculatedSize) + "\n" +
                "وقف الخسارة:  " + TradeManager.formatPrice(sl) + "\n" +
                "هدف الربح:    " + TradeManager.formatPrice(calculatedTP) + "\n\n" +
                "خسارة:        $" + tradeManager.getRiskAmount() + "\n" +
                "ربح:          $" + tradeManager.getRewardAmount() + "\n" +
                "نسبة R/R:     1:" + String.format(Locale.US, "%.2f", rr)
            )
            .setPositiveButton("تنفيذ", (d, w) -> executeTrade(sl, qtyStr))
            .setNegativeButton("إلغاء", null)
            .show();
    }

    private void executeTrade(double sl, String qtyStr) {
        String apiKey    = tradeManager.getApiKey();
        String apiSecret = tradeManager.getApiSecret();

        if (apiKey.isEmpty()) { simulateTrade(sl, qtyStr); return; }

        btnExecute.setEnabled(false);
        btnExecute.setText("⏳ جاري التنفيذ...");

        binanceService.executeMarketBuy(apiKey, apiSecret, selectedSymbol, qtyStr,
            new BinanceService.Callback<BinanceApi.OrderResponse>() {
                @Override
                public void onSuccess(BinanceApi.OrderResponse order) {
                    double execPrice = currentPrice;
                    if (order.fills != null && !order.fills.isEmpty()) {
                        double c = 0, q = 0;
                        for (BinanceApi.OrderResponse.Fill f : order.fills) {
                            q += Double.parseDouble(f.qty);
                            c += Double.parseDouble(f.qty) * Double.parseDouble(f.price);
                        }
                        if (q > 0) execPrice = c / q;
                    }
                    saveTrade(sl, execPrice, String.valueOf(order.orderId), qtyStr);
                    btnExecute.setEnabled(true);
                    btnExecute.setText("⚡  تنفيذ الصفقة");
                    askForOco(sl, execPrice, qtyStr);
                }
                @Override
                public void onError(String error) {
                    btnExecute.setEnabled(true);
                    btnExecute.setText("⚡  تنفيذ الصفقة");
                    new AlertDialog.Builder(NewTradeActivity.this)
                        .setTitle("❌ فشل التنفيذ")
                        .setMessage("السبب:\n" + error + "\n\nتحقق من:\n• رصيد USDT كافٍ\n• تفعيل Spot Trading في API\n• IP Restrictions → Unrestricted")
                        .setPositiveButton("موافق", null).show();
                }
            });
    }

    private void simulateTrade(double sl, String qtyStr) {
        saveTrade(sl, currentPrice, "SIM-" + (System.currentTimeMillis() % 100000), qtyStr);
        new AlertDialog.Builder(this)
            .setTitle("✓ محاكاة")
            .setMessage("تم حفظ الصفقة في وضع المحاكاة\n\nلتنفيذ حقيقي → الإعدادات → أضف مفاتيح API")
            .setPositiveButton("موافق", (d, w) -> finish()).show();
    }

    private void saveTrade(double sl, double execPrice, String orderId, String qty) {
        double risk   = tradeManager.getRiskAmount();
        double reward = tradeManager.getRewardAmount();
        TradeManager.Trade trade = new TradeManager.Trade();
        trade.symbol          = selectedSymbol;
        trade.entryPrice      = execPrice;
        trade.positionSize    = TradeManager.calcPositionSize(execPrice, sl, risk);
        trade.stopLoss        = sl;
        trade.takeProfit      = TradeManager.calcTakeProfit(execPrice, reward, trade.positionSize);
        trade.riskAmount      = risk;
        trade.potentialProfit = reward;
        trade.orderId         = orderId;
        trade.riskRewardRatio = "1:" + TradeManager.formatPrice(reward / risk);
        tradeManager.addTrade(trade);
    }

    private void askForOco(double sl, double execPrice, String qty) {
        new AlertDialog.Builder(this)
            .setTitle("OCO تلقائي")
            .setMessage("تم تنفيذ الشراء ✓\n\nهل تريد وضع أوامر OCO (وقف الخسارة + هدف الربح) تلقائياً؟")
            .setPositiveButton("نعم", (d, w) -> placeOco(sl, execPrice, qty))
            .setNegativeButton("لا", (d, w) -> { Snackbar.make(btnExecute, "✓ تم بنجاح", Snackbar.LENGTH_SHORT).show(); finish(); })
            .show();
    }

    private void placeOco(double sl, double execPrice, String qty) {
        double tp = TradeManager.calcTakeProfit(execPrice, tradeManager.getRewardAmount(),
                TradeManager.calcPositionSize(execPrice, sl, tradeManager.getRiskAmount()));

        if (tp <= execPrice) { showOcoError("هدف الربح أقل من سعر الدخول."); return; }
        if (sl >= execPrice) { showOcoError("وقف الخسارة أعلى من سعر الدخول."); return; }

        String tpStr  = BinanceService.roundPrice(tp,  symbolInfo.tickSize);
        String slStr  = BinanceService.roundPrice(sl,  symbolInfo.tickSize);
        String slLim  = BinanceService.roundPrice(sl * 0.998, symbolInfo.tickSize);

        // استخدم BinanceOco مباشرة (OkHttp) - يحل مشكلة signature -1022
        binanceOco.placeOco(
            tradeManager.getApiKey(), tradeManager.getApiSecret(),
            selectedSymbol, qty, tpStr, slStr, slLim,
            new BinanceOco.OcoCallback() {
                @Override
                public void onSuccess(String orderListId) {
                    new AlertDialog.Builder(NewTradeActivity.this)
                        .setTitle("✅ تم بنجاح!")
                        .setMessage("تم الشراء ووضع OCO 🎉\n\nTP: " + tpStr + "\nSL: " + slStr + "\n\nرقم OCO: " + orderListId)
                        .setPositiveButton("ممتاز", (d, w) -> finish()).show();
                }
                @Override
                public void onError(String error) {
                    new AlertDialog.Builder(NewTradeActivity.this)
                        .setTitle("⚠ تم الشراء - OCO يدوي")
                        .setMessage("تم الشراء ✓\n\nضع OCO يدوياً في Binance:\nTP: " + tpStr + "\nSL: " + slStr + "\n\nالخطأ: " + error)
                        .setPositiveButton("موافق", (d, w) -> finish()).show();
                }
            });
    }

    private void showOcoError(String msg) {
        new AlertDialog.Builder(this).setTitle("خطأ OCO").setMessage(msg).setPositiveButton("موافق", null).show();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) { finish(); return true; }
        return super.onOptionsItemSelected(item);
    }
}
