package com.trading.smart;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.widget.ProgressBar;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class SplashActivity extends AppCompatActivity {

    private ProgressBar progressBar;
    private TextView statusText;
    private Handler handler = new Handler();
    private int progress = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        progressBar = findViewById(R.id.progressBar);
        statusText = findViewById(R.id.statusText);

        // Animate logo
        AlphaAnimation fadeIn = new AlphaAnimation(0f, 1f);
        fadeIn.setDuration(800);
        findViewById(R.id.logoIcon).startAnimation(fadeIn);
        findViewById(R.id.appTitle).startAnimation(fadeIn);

        startProgress();
    }

    private void startProgress() {
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                progress += 5;
                progressBar.setProgress(progress);

                if (progress == 30) statusText.setText("جاري تحميل الإعدادات...");
                else if (progress == 60) statusText.setText("جاري الاتصال بـ Binance...");
                else if (progress == 90) statusText.setText("تم! ✓");

                if (progress < 100) {
                    handler.postDelayed(this, 40);
                } else {
                    handler.postDelayed(() -> {
                        Intent intent = new Intent(SplashActivity.this, MainActivity.class);
                        startActivity(intent);
                        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
                        finish();
                    }, 400);
                }
            }
        }, 40);
    }
}
