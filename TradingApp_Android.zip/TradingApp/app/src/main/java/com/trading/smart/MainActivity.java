package com.trading.smart;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.snackbar.Snackbar;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private TradeManager tradeManager;
    private BinanceService binanceService;
    private BinanceWebSocket wsClient;
    private TextView tvConnectionStatus, tvBalance, tvWins, tvLosses, tvWinRate;
    private RecyclerView rvPrices;
    private PricesAdapter pricesAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tradeManager = TradeManager.getInstance(this);
        binanceService = BinanceService.getInstance();
        wsClient = BinanceWebSocket.getInstance();

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("أداة التداول الذكية");

        tvConnectionStatus = findViewById(R.id.tvConnectionStatus);
        tvBalance          = findViewById(R.id.tvBalance);
        tvWins             = findViewById(R.id.tvWins);
        tvLosses           = findViewById(R.id.tvLosses);
        tvWinRate          = findViewById(R.id.tvWinRate);

        rvPrices = findViewById(R.id.rvPrices);
        rvPrices.setLayoutManager(new LinearLayoutManager(this));

        findViewById(R.id.btnNewTrade).setOnClickListener(v -> startActivity(new Intent(this, NewTradeActivity.class)));
        findViewById(R.id.btnReview).setOnClickListener(v -> startActivity(new Intent(this, ReviewActivity.class)));
        findViewById(R.id.btnStats).setOnClickListener(v -> startActivity(new Intent(this, StatisticsActivity.class)));
    }

    @Override
    protected void onResume() {
        super.onResume();
        updateStats();
        setupLivePrices();
        tryConnect();
    }

    @Override
    protected void onPause() {
        super.onPause();
        wsClient.disconnect();
    }

    private void setupLivePrices() {
        List<String> pairs = tradeManager.getTradingPairs();
        pricesAdapter = new PricesAdapter(pairs, s -> {});
        rvPrices.setAdapter(pricesAdapter);

        // WebSocket - أسعار لحظية حقيقية
        wsClient.connect(pairs);
        for (String symbol : pairs) {
            wsClient.subscribe(symbol, (sym, price) -> pricesAdapter.updatePrice(sym, price));
        }
    }

    private void updateStats() {
        TradeManager.Stats s = tradeManager.getAllTimeStats();
        tvWins.setText(String.valueOf(s.wins));
        tvLosses.setText(String.valueOf(s.losses));
        tvWinRate.setText(String.format("%.0f%%", s.winRate));
    }

    private void tryConnect() {
        String apiKey = tradeManager.getApiKey();
        String apiSecret = tradeManager.getApiSecret();

        if (apiKey.isEmpty()) {
            tvConnectionStatus.setText("وضع المحاكاة — أضف API في الإعدادات");
            tvConnectionStatus.setTextColor(getColor(R.color.text_secondary));
            tvBalance.setText("الرصيد: غير متصل");
            return;
        }
        tvConnectionStatus.setText("جاري الاتصال...");
        tvConnectionStatus.setTextColor(getColor(R.color.text_secondary));

        binanceService.getBalance(apiKey, apiSecret, new BinanceService.Callback<Double>() {
            @Override
            public void onSuccess(Double balance) {
                tvConnectionStatus.setText("● متصل بـ Binance");
                tvConnectionStatus.setTextColor(getColor(R.color.green));
                tvBalance.setText("الرصيد: $" + TradeManager.formatPrice(balance) + " USDT");
            }
            @Override
            public void onError(String error) {
                tvConnectionStatus.setText("✗ فشل الاتصال — تحقق من مفاتيح API");
                tvConnectionStatus.setTextColor(getColor(R.color.red));
                tvBalance.setText("");
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        menu.add(Menu.NONE, 1, Menu.NONE, "الإعدادات").setIcon(android.R.drawable.ic_menu_preferences).setShowAsAction(MenuItem.SHOW_AS_ACTION_ALWAYS);
        menu.add(Menu.NONE, 2, Menu.NONE, "تحديث").setIcon(android.R.drawable.ic_menu_rotate).setShowAsAction(MenuItem.SHOW_AS_ACTION_ALWAYS);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == 1) startActivity(new Intent(this, SettingsActivity.class));
        else if (item.getItemId() == 2) {
            updateStats(); tryConnect();
            Snackbar.make(findViewById(android.R.id.content), "تم التحديث", Snackbar.LENGTH_SHORT).show();
        }
        return true;
    }
}
