package com.trading.smart;

import android.os.Handler;
import android.os.Looper;
import org.apache.commons.codec.binary.Hex;
import retrofit2.Call;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import okhttp3.OkHttpClient;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.concurrent.TimeUnit;
import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

public class BinanceService {

    private static final String BASE_URL = "https://api.binance.com/";
    private BinanceApi api;
    private static BinanceService instance;
    private Handler mainHandler = new Handler(Looper.getMainLooper());

    public interface Callback<T> {
        void onSuccess(T result);
        void onError(String error);
    }

    public static class SymbolInfo {
        public double stepSize = 0.001;
        public double minQty   = 0.001;
        public double tickSize = 0.01;
    }

    public static BinanceService getInstance() {
        if (instance == null) instance = new BinanceService();
        return instance;
    }

    private BinanceService() {
        OkHttpClient client = new OkHttpClient.Builder()
                .connectTimeout(15, TimeUnit.SECONDS)
                .readTimeout(15, TimeUnit.SECONDS)
                .build();
        api = new Retrofit.Builder()
                .baseUrl(BASE_URL)
                .client(client)
                .addConverterFactory(GsonConverterFactory.create())
                .build()
                .create(BinanceApi.class);
    }

    public void getPrice(String symbol, Callback<Double> callback) {
        api.getPrice(symbol).enqueue(new retrofit2.Callback<BinanceApi.PriceResponse>() {
            @Override
            public void onResponse(Call<BinanceApi.PriceResponse> call, retrofit2.Response<BinanceApi.PriceResponse> r) {
                if (r.isSuccessful() && r.body() != null) {
                    try { mainHandler.post(() -> callback.onSuccess(Double.parseDouble(r.body().price))); }
                    catch (Exception e) { mainHandler.post(() -> callback.onError("خطأ")); }
                } else {
                    mainHandler.post(() -> callback.onError("رمز غير صحيح"));
                }
            }
            @Override public void onFailure(Call<BinanceApi.PriceResponse> call, Throwable t) {
                mainHandler.post(() -> callback.onError("فشل الاتصال"));
            }
        });
    }

    public void getSymbolInfo(String symbol, Callback<SymbolInfo> callback) {
        api.getExchangeInfo(symbol).enqueue(new retrofit2.Callback<BinanceApi.ExchangeInfoResponse>() {
            @Override
            public void onResponse(Call<BinanceApi.ExchangeInfoResponse> call, retrofit2.Response<BinanceApi.ExchangeInfoResponse> r) {
                SymbolInfo info = new SymbolInfo();
                try {
                    if (r.isSuccessful() && r.body() != null && r.body().symbols != null && !r.body().symbols.isEmpty()) {
                        for (BinanceApi.ExchangeInfoResponse.Filter f : r.body().symbols.get(0).filters) {
                            if ("LOT_SIZE".equals(f.filterType)) {
                                info.stepSize = Double.parseDouble(f.stepSize);
                                info.minQty   = Double.parseDouble(f.minQty);
                            }
                            if ("PRICE_FILTER".equals(f.filterType)) {
                                info.tickSize = Double.parseDouble(f.tickSize);
                            }
                        }
                    }
                } catch (Exception ignored) {}
                mainHandler.post(() -> callback.onSuccess(info));
            }
            @Override public void onFailure(Call<BinanceApi.ExchangeInfoResponse> call, Throwable t) {
                mainHandler.post(() -> callback.onSuccess(new SymbolInfo()));
            }
        });
    }

    public void getBalance(String apiKey, String apiSecret, Callback<Double> callback) {
        long ts = System.currentTimeMillis();
        String sig = sign("timestamp=" + ts, apiSecret);
        api.getAccount(ts, sig, apiKey).enqueue(new retrofit2.Callback<BinanceApi.AccountResponse>() {
            @Override
            public void onResponse(Call<BinanceApi.AccountResponse> call, retrofit2.Response<BinanceApi.AccountResponse> r) {
                if (r.isSuccessful() && r.body() != null) {
                    double bal = 0;
                    for (BinanceApi.AccountResponse.Balance b : r.body().balances)
                        if ("USDT".equals(b.asset)) { bal = Double.parseDouble(b.free); break; }
                    final double fb = bal;
                    mainHandler.post(() -> callback.onSuccess(fb));
                } else {
                    mainHandler.post(() -> callback.onError("فشل جلب الرصيد: " + r.code()));
                }
            }
            @Override public void onFailure(Call<BinanceApi.AccountResponse> call, Throwable t) {
                mainHandler.post(() -> callback.onError("فشل الاتصال"));
            }
        });
    }

    public void executeMarketBuy(String apiKey, String apiSecret, String symbol,
                                  String quantity, Callback<BinanceApi.OrderResponse> callback) {
        long ts = System.currentTimeMillis();
        String params = "symbol=" + symbol + "&side=BUY&type=MARKET&quantity=" + quantity + "&timestamp=" + ts;
        String sig = sign(params, apiSecret);
        api.createOrder(apiKey, symbol, "BUY", "MARKET", quantity, ts, sig)
           .enqueue(new retrofit2.Callback<BinanceApi.OrderResponse>() {
               @Override
               public void onResponse(Call<BinanceApi.OrderResponse> call, retrofit2.Response<BinanceApi.OrderResponse> r) {
                   if (r.isSuccessful() && r.body() != null) {
                       mainHandler.post(() -> callback.onSuccess(r.body()));
                   } else {
                       try {
                           String err = r.errorBody() != null ? r.errorBody().string() : String.valueOf(r.code());
                           mainHandler.post(() -> callback.onError(err));
                       } catch (Exception e) { mainHandler.post(() -> callback.onError("خطأ " + r.code())); }
                   }
               }
               @Override public void onFailure(Call<BinanceApi.OrderResponse> call, Throwable t) {
                   mainHandler.post(() -> callback.onError(t.getMessage()));
               }
           });
    }

    /**
     * OCO الجديد - API 2024
     * aboveType = LIMIT_MAKER (هدف الربح)
     * belowType = STOP_LOSS_LIMIT (وقف الخسارة)
     */
    public void placeOcoOrder(String apiKey, String apiSecret, String symbol,
                               String qty, String tp, String sl, String slLimit,
                               Callback<BinanceApi.OcoResponse> callback) {
        long ts = System.currentTimeMillis();

        // ترتيب أبجدي للـ signature
        String params = "abovePrice=" + tp +
                "&aboveType=LIMIT_MAKER" +
                "&belowPrice=" + slLimit +
                "&belowStopPrice=" + sl +
                "&belowTimeInForce=GTC" +
                "&belowType=STOP_LOSS_LIMIT" +
                "&quantity=" + qty +
                "&side=SELL" +
                "&symbol=" + symbol +
                "&timestamp=" + ts;

        String sig = sign(params, apiSecret);

        api.createOcoOrder(
                apiKey, symbol, "SELL", qty,
                "LIMIT_MAKER", tp,
                "STOP_LOSS_LIMIT", sl, slLimit, "GTC",
                ts, sig
        ).enqueue(new retrofit2.Callback<BinanceApi.OcoResponse>() {
            @Override
            public void onResponse(Call<BinanceApi.OcoResponse> call, retrofit2.Response<BinanceApi.OcoResponse> r) {
                if (r.isSuccessful() && r.body() != null) {
                    mainHandler.post(() -> callback.onSuccess(r.body()));
                } else {
                    try {
                        String err = r.errorBody() != null ? r.errorBody().string() : String.valueOf(r.code());
                        mainHandler.post(() -> callback.onError(err));
                    } catch (Exception e) { mainHandler.post(() -> callback.onError("خطأ OCO: " + r.code())); }
                }
            }
            @Override public void onFailure(Call<BinanceApi.OcoResponse> call, Throwable t) {
                mainHandler.post(() -> callback.onError(t.getMessage()));
            }
        });
    }

    // تقريب الكمية حسب stepSize
    public static String roundQty(double qty, double stepSize) {
        if (stepSize <= 0) stepSize = 0.001;
        BigDecimal step    = new BigDecimal(String.valueOf(stepSize));
        BigDecimal rounded = new BigDecimal(String.valueOf(qty))
                .divide(step, 0, RoundingMode.FLOOR).multiply(step);
        return rounded.setScale(Math.max(step.scale(), 0), RoundingMode.FLOOR).toPlainString();
    }

    // تقريب السعر حسب tickSize
    public static String roundPrice(double price, double tickSize) {
        if (tickSize <= 0) tickSize = 0.0001;
        BigDecimal tick    = new BigDecimal(String.valueOf(tickSize));
        BigDecimal rounded = new BigDecimal(String.valueOf(price))
                .divide(tick, 0, RoundingMode.FLOOR).multiply(tick);
        return rounded.setScale(Math.max(tick.scale(), 0), RoundingMode.FLOOR).toPlainString();
    }

    private String sign(String data, String secret) {
        try {
            Mac mac = Mac.getInstance("HmacSHA256");
            mac.init(new SecretKeySpec(secret.getBytes("UTF-8"), "HmacSHA256"));
            return new String(Hex.encodeHex(mac.doFinal(data.getBytes("UTF-8"))));
        } catch (Exception e) { return ""; }
    }
}
